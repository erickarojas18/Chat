import mongoose from 'mongoose';
import Message from './models/busquedaModel.mjs';

// Conexión reutilizable
let isConnected = false;

const connectDB = async () => {
  if (isConnected) return;

  await mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  isConnected = true;
};

export const handler = async (event) => {
  await connectDB(); // usamos conexión reutilizable

  const { from, to, keyword, startDate, endDate } = event.queryStringParameters || {}; 

  if (!from || !to) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Se requieren los campos "from" y "to"' }),
    };
  }

  const filters = {
    from,
    to,
  };

  // Filtro por contenido
  if (keyword) {
    filters.content = { $regex: keyword, $options: 'i' };
  }

  // Filtro por fechas usando 'timestamp'
  if (startDate || endDate) {
    filters.timestamp = {};
    if (startDate) filters.timestamp.$gte = new Date(startDate);
    if (endDate) filters.timestamp.$lte = new Date(endDate);
  }

  try {
    const messages = await Message.find(filters).sort({ timestamp: 1 });
    return {
      statusCode: 200,
      body: JSON.stringify(messages),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ message: error.message }),
    };
  }
};
