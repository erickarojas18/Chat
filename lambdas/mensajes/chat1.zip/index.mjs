import dbConnect from './dbConnect.mjs'; // Conexión a MongoDB
import Message from './models/messageModel.mjs';

export const handler = async (event) => {
  await dbConnect();
  const { from, to, content } = JSON.parse(event.body);

  if (!from || !to || !content) {
    return { statusCode: 400, body: JSON.stringify({ message: 'Faltan datos' }) };
  }

  const message = new Message({ from, to, content });

  try {
    await message.save();
    return { statusCode: 200, body: JSON.stringify({ message: 'Mensaje enviado' }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ message: error.message }) };
  }
};
